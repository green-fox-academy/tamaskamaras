package hu.ejogseged.challenge;

import java.util.*;

public class ArrayScanner
{
    private int[] array;

    //
    // Tedd lehetővé az osztály példányosítása során egy tömb (array) példány változóként történő beállítását.
    //
    public ArrayScanner( int[] array )
    {
        // TODO
        this.array = array;
    }

    public int[] getArray()
    {
        return array;
    }

    //
    // Készíts egy olyan asszociatív tömböt (HashMap<String, ArrayList>-et), aminek két kulcsa van a következőknek megfelelően:
    // { "paros" => [ ... ], "paratlan" => [ ... ] }
    // A "paros" kulcshoz kapcsolódó tömbbe a példányosítás során megadott tömbben (az objektum array változójában) szereplő páros számokat, a "paratlan" kulcshoz kapcsolódó tömbbe a példányosítás során megadott tömbben (az objektum array változójában) szereplő páratlan számokat kellene összegyűjteni.
    //
    public HashMap<String, ArrayList> evenAndOddNumbers()
    {
        // return null; // TODO
        ArrayList evenArray = new ArrayList();
        ArrayList oddArray  = new ArrayList();
        for( int number : getArray() )
            if( number % 2 == 0 )
                evenArray.add(number);
            else
                oddArray.add(number);
        HashMap<String, ArrayList> result = new HashMap<String, ArrayList>();
        result.put("paros", evenArray);
        result.put("paratlan", oddArray);
        return result;
    }

    //
    // Keresd meg a példányosítás során megadott tömbnek (az objektum array változójának) maximális értékű, páratlan elemét.
    // Ha nincs a tömbben páratlan szám, akkor a visszatérési érték legyen 0.
    //
    public int maximalOddNumber()
    {
        // return 0; // TODO
        int bestNumber = 0;
        for( int number : getArray() )
            if( ( number % 2 == 1 ) && ( bestNumber < number ) )
                bestNumber = number;
        return bestNumber;
    }

    //
    // Igaz az az állítás, miszerint a példányosítás során megadott tömbnek (az objektum array változójának) minden eleme osztható 3-mal?
    //
    public boolean allNumbersAreDividableBy3()
    {
        // return false; // TODO
        boolean result = true;
        for( int number : getArray() )
            result = result && ( number % 3 == 0 );
        return result;
    }

    //
    // Definiálj egy olyan metódust, ami
    // * paraméterül kap egy pozitív egész számot (center) és
    // * előállít egy olyan (HashMap<Integer, Integer>) adatszerkezetet, ami tartalmazza, hogy a center változóban megadott szám (radius) 5 sugarú környezetében és a példányosítás során megadott tömbben (az objektum array változójában) is szereplő számok közül melyik hányszor szerepelt.
    //
    public HashMap<Integer, Integer> neighborhoodOfPoint(int center)
    {
        int radius = 5;
        // return null; // TODO
        int min    = center - radius;
        int max    = center + radius;
        HashMap<Integer, Integer> result = new HashMap<Integer, Integer>();
        int count;
        for( int number : getArray() )
            if( ( min <= number ) && ( number <= max ) )
            {
                if( result.containsKey(number) )
                    count = result.get(number);
                else
                    count = 0;
                result.put(number, count + 1);
            }
        return result;
    }
}
