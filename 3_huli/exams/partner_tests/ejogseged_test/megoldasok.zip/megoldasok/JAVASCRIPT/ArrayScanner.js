class ArrayScanner {
  //
  // Tedd lehetővé az osztály példányosítása során egy tömb (array) példány változóként történő beállítását.
  //
  constructor(array) {
    // TODO
    this.array = array;
  }

  //
  // Készíts egy olyan objektumot, aminek két kulcsa van a következőknek megfelelően:
  // { paros: [ ... ], paratlan: [ ... ] }
  // A "paros" kulcshoz kapcsolódó tömbbe a példányosítás során megadott tömbben (az objektum array változójában) szereplő páros számokat, a "paratlan" kulcshoz kapcsolódó tömbbe a példányosítás során megadott tömbben (az objektum array változójában) szereplő páratlan számokat kellene összegyűjteni.
  //
  evenAndOddNumbers() {
    // TODO
    var result = { paros: [], paratlan: [] },
      array = this.array,
      number;
    for( var i = 0; i < array.length; ++i ) {
      number = array[i];
      result[(number % 2 == 0) ? "paros" : "paratlan"].push(number);
    }
    return result;
  }

  //
  // Keresd meg a példányosítás során megadott tömbnek (az objektum array változójának) maximális értékű, páratlan elemét.
  // Ha nincs a tömbben páratlan szám, akkor a visszatérési érték legyen 0.
  //
  maximalOddNumber() {
    // TODO
    var array = this.array,
      bestNumber = 0,
      number;
    for( var i = 0; i < array.length; ++i ) {
      number = array[i];
      if( ( number % 2 == 1 ) && ( number > bestNumber ) )
        bestNumber = number;
    }
    return bestNumber;
  }

  //
  // Igaz az az állítás, miszerint a példányosítás során megadott tömbnek (az objektum array változójának) minden eleme osztható 3-mal?
  //
  allNumbersAreDividableBy3() {
    // TODO
    var array = this.array,
      l = true;
    for( var i = 0; i < array.length; ++i ) {
      l = l && ( array[i] % 3 == 0 );
    }
    return l;
  }

  //
  // Definiálj egy olyan metódust, ami
  // * paraméterül kap egy pozitív egész számot (center) és
  // * előállít egy olyan object-et, ami tartalmazza, hogy a center változóban megadott szám (radius) 5 sugarú környezetében és a példányosítás során megadott tömbben (az objektum array változójában) is szereplő számok közül melyik hányszor szerepelt.
  //
  neighborhoodOfPoint(center) {
    var radius = 5;
    // TODO
    var array = this.array,
      result = {},
      min = center - radius,
      max = center + radius,
      number;
    for( var i = 0; i < array.length; ++i ) {
      number = array[i];
      if( ( min <= number ) && ( number <= max ) ) {
        if( result[number] == null )
          result[number] = 0;
        result[number] += 1;
      }
    }
    return result;
  }
}
